Spire1 形态 Beta r3

构建标识: Spire1-Forms-Beta-20261003-r3
Manifest 版本: 1.2.3
构建日期: 2026-10-03
目标: Slay the Spire 2 public beta v0.111.x

包内容
  mods/Spire1/Spire1.dll
  mods/Spire1/Spire1.pck
  mods/Spire1/Spire1.json

依赖
  - 必须先安装 BaseLib 3.4.5 或更高版本。
  - Watcher 是可选项。未安装 Watcher 时 Spire1 仍会加载，但形态桥接会安全关闭。
  - AutoAnthony 和 AutoAnthonyWatcher 仅是可选运行时桥接，不是 Spire1 的 manifest 硬前置。
  - 如果尝试多人测试，每个客户端都应安装相同的 Spire1 文件。

安装
  1. 将本压缩包解压到 Slay the Spire 2 游戏目录。
  2. 确认最终路径包含 mods/Spire1/Spire1.dll、Spire1.pck 和 Spire1.json。
  3. 在 Mod 列表中启用 Spire1，并单独安装 BaseLib 3.4.5 或更高版本。
  4. 只有在测试对应可选桥接时才安装 Watcher、AutoAnthony 或 AutoAnthonyWatcher。

Beta 范围
  - 本版本包含 Calm、Wrath、Divinity 三条 Watcher 形态卡入口和效果链。
  - 当前 DLL 已在隔离真实运行中完成三形态出牌烟测，并完成可选 Mod 交叉启动矩阵。
  - 这是 Beta 包；可见 UI、视觉动画、长战斗平衡、战中存档/读档、重连和多人行为尚未宣称完整验收。
  - 本公开包有意排除调试符号 Spire1.pdb。

第三方提示
  AutoAnthony 可能在自身内容自检中报告 Colorless 卡数量不匹配。这是第三方版本/内容提示，不是 Spire1 的 manifest 依赖。

SHA256
  Spire1.dll  4F49BA0D2BE134C6EFD149E96E4B94387E0AA873DFFE40AA7368FC41EBBD88C2
  Spire1.pck   70CCBB4D1A2DD1439152F030E40B4C1A8BCA775547EB4F8273C956F62BB51C79
  Spire1.json  CDBD57D54374285503538D866551B897938A5D540C2285CE5068019565BB9305
