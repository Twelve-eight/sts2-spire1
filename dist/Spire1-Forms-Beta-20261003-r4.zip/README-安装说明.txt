Spire1: StS1 Characters
姿态形态 Mod Beta r4

版本信息
- Spire1 版本: 1.2.3
- 目标游戏版本: 0.111.0
- BaseLib 最低版本: 3.4.5

安装
1. 将本压缩包中的 mods\Spire1\ 目录解压到游戏根目录的 mods\ 目录。
2. 保持文件结构为 mods\Spire1\Spire1.dll、Spire1.pck、Spire1.json。
3. 启动游戏后，在 Mod 列表中确认 BaseLib 与 Spire1 已加载。

依赖与可选桥接
- BaseLib >= 3.4.5 是 manifest 声明的唯一硬依赖。
- Watcher、AutoAnthony、AutoAnthonyWatcher 都是可选运行时桥接，不是 Spire1 manifest 硬前置。
- 未安装 Watcher 时，姿态形态功能会 fail-closed；Spire1 本体仍可加载。

本版已验证
- 2026-10-03 在隔离非 Steam 游戏副本中，以本压缩包使用的 Release DLL/PCK 完成三形态单场景真实 smoke。
- Calm: WATCHER_VIGILANCE -> VoidSerpentStancePower；两次 WATCHER_STRIKE_P 均完成，第一次免费，第二次支付 1 能量，每次总伤害 9。
- Wrath: WATCHER_ERUPTION_P -> DemonReaperStancePower；WATCHER_STRIKE_P 造成 7 点伤害，StrengthPower=1，目标 DoomPower=7，能量 1 -> 0。
- Divinity: WATCHER_BLASPHEMY -> EchoCelestialStancePower；WATCHER_STRIKE_P 造成 12 点总伤害，Echo 完成增量 2，两次 play count 均为 2。
- 三场景均通过 formGateAfter 与 effectVerification，unobservedFaults 为空；进程正常退出，测试 mods 清理，Steam settings 恢复，共享 mod_configs 未变化。
- 长回合边界 smoke 已执行到 Divinity 的自杀 power；该分支诚实记录为 partial/blocked，因为 EndTurnDeathPower 会在下一回合开始杀死玩家并结束战斗，不把它宣称为完整长回合通过。

尚未验证
- 可见 UI、图像与动画呈现。
- 多人同步、战中存档/读档、重连、性能和完整平衡。
- 完整长战斗、所有回合边界，以及朋友机器上的安装与可见运行。
- headless smoke 中的 crashpad、Dummy renderer、Godot RID/resource leak 仅视为环境噪声，未宣称为业务通过。

文件完整性
- Spire1.dll SHA256: 883CD438435A651DF8BF0A1DE5D9C28467E5A7CF8B14B561015C436E70FFF519
- Spire1.pck SHA256: 3AA0BD39173C491301BCF42F3FB5ADA25A4762794F0C86B119239824A8CFC545
- Spire1.json SHA256: CDBD57D54374285503538D866551B897938A5D540C2285CE5068019565BB9305
- 最终 ZIP SHA256: 见压缩包同目录的 Spire1-Forms-Beta-20261003-r4.zip.sha256 及发布报告。说明文件位于压缩包内部，不能把压缩包自身哈希写回包内而同时保持该哈希不变；外部 sidecar 是最终 ZIP 字节的校验值。

这是 Beta 测试副本，不是完整产品验收。发现崩溃或异常时，请保留游戏日志、Mod 列表和复现步骤。